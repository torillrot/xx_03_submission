empty_function <- function(){
  print(1)
}